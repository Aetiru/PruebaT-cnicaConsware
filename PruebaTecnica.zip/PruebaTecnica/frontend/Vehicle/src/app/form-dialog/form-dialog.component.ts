import { Component, Inject } from '@angular/core';
import { MatDialog, MatDialogModule, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-form-dialog',
  standalone: true,
  imports: [
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  templateUrl: './form-dialog.component.html',
  styleUrls: ['./form-dialog.component.css']
})
export class FormDialogComponent {

  checkoutForm: FormGroup;
  apiUrl = 'http://localhost:5126/api/Vehicles';
  option = "";
  id = 0;
  values = []
  constructor(
    private dialog: MatDialog,
    private formBuilder: FormBuilder,
    private http: HttpClient,
    @Inject(MAT_DIALOG_DATA) public data: any,

  ) {
    this.values = data.vehicle;
    this.checkoutForm = this.formBuilder.group({
      make: this.values == undefined ? '' : data.vehicle.make,
      model: this.values == undefined ? '' : data.vehicle.model,
      year: this.values == undefined ? '' : data.vehicle.year
    });

    this.option = data.option
    this.id = data.vehicle?.id

  }

  onSubmit() {

    const formData = this.checkoutForm.value;
    if (this.option == 'create') {
      this.create(formData)
    } else {
      this.edit(this.id, formData)
    }

  }

  create(data: any) {
    this.http.post(this.apiUrl, data).subscribe(
      (response) => {
        console.log('Vehículo creado exitosamente:', response);
        alert("Vehículo creado exitosamente");
      },
      (error) => {
        console.error('Error al crear el vehículo:', error);
      }
    );
  }

  edit(id: number, data: any) {
    this.http.put(this.apiUrl + `/${id}`, data).subscribe(
      (response) => {
        console.log('Registro editado correctamente:', response);
        alert('Registro editado correctamente')
      },
      (error) => {
        console.error('Error al crear el vehículo:', error);
      }
    );
  }

}
