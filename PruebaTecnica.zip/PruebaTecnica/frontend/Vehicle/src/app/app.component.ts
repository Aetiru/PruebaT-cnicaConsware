import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';
import { FormDialogComponent } from './form-dialog/form-dialog.component';
import { MatDialog } from '@angular/material/dialog';


interface Vehicle {
  id: number;
  make: string;
  model: string;
  year: number;
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule,
    RouterOutlet,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatDialogModule],

  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})

export class AppComponent implements OnInit {

  constructor(private dialog: MatDialog, private formBuilder: FormBuilder) {
    this.searchForm = this.formBuilder.group({
      search: ['']
    });
  }

  title = 'CRUD Vehiculos';

  url: string = 'http://localhost:5126/api/Vehicles'

  data: Vehicle[] = []

  searchForm: FormGroup;


  async ngOnInit(): Promise<void> {
    this.init()
    if (this.searchForm.get('search')) {
      this.searchForm.get('search')!.valueChanges.subscribe(value => {
        if (value.length >= 3) {
          this.search(value);
        }

        if (value.length == 0) {
          this.init()
        }
      });
    }

  }

  async search(value: string) {
    this.data = await fetch(`${this.url}/search?name=${value}`)
      .then((response) => response.json())
    console.log('Realizar búsqueda con:', this.data);
  }

  async init() {
    this.data = await fetch(this.url)
      .then((response) => response.json())
  }


  delete(vehicle: Vehicle) {
    const id = vehicle.id
    fetch(this.url + `/${id}`, {
      method: 'DELETE'
    }).then((res) => {
      this.init()
    })


  }

  openDialog(option: string, vehicle?: Vehicle): void {
    const dialogRef = this.dialog.open(FormDialogComponent, {
      data: { vehicle: vehicle, option: option },
    });

    dialogRef.afterClosed().subscribe((result: any) => {
      this.init()
    });
  }
}
