using Microsoft.EntityFrameworkCore;
using VehicleCRUD.API.Models;

namespace VehicleCRUD.API.Data
{

    public class VehicleDbContext : DbContext
    {
        public VehicleDbContext(DbContextOptions<VehicleDbContext> options) : base(options)
        {
        }

        public DbSet<Vehicle> Vehicles { get; set; }
    }
}


