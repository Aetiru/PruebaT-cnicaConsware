using System;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VehicleCRUD.API.Data;
using VehicleCRUD.API.Models;

namespace VehicleCRUD.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VehiclesController : ControllerBase
    {
        private readonly VehicleDbContext _context;

        public VehiclesController(VehicleDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Vehicle>>> GetVehicles()
        {
            return await _context.Vehicles
                .Select(x => (x))
                .ToListAsync();
        }

        //Get by Id: api/Vehicles/1
        [HttpGet("{id}")]
        public async Task<ActionResult<Vehicle>> GetVehicle(int id)
        {

            var vehicle = await _context.Vehicles.FindAsync(id);

            if (vehicle == null)
            {
                return NotFound();
            }

            return vehicle;

        }

        // POST: api/Vehicles
        [HttpPost]
        public async Task<ActionResult<Vehicle>> PostVehicle(Vehicle vehicle)
        {
            _context.Vehicles.Add(vehicle);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(PostVehicle), new { id = vehicle.Id }, vehicle);
        }

        // PUT: api/Vehicles/1
        [HttpPut("{id}")]
        public async Task<IActionResult> PutVehicle(int id, Vehicle vehicle)
        {
            // if (id != vehicle.Id)
            // {
            //     return BadRequest();
            // }

            var vehicles = await _context.Vehicles.FindAsync(id);
            if (vehicles == null)
            {
                return NotFound();
            }

            vehicles.Make = vehicle.Make;
            vehicles.Model = vehicle.Model;
            vehicles.year = vehicle.year;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException) when (!VehicleItemExists(id))
            {
                return NotFound();
            }

            return NoContent();

        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteVehicle(int id)
        {
            var todoItem = await _context.Vehicles.FindAsync(id);
            if (todoItem == null)
            {
                return NotFound();
            }

            _context.Vehicles.Remove(todoItem);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        [HttpGet("search")]
        public async Task<ActionResult<IEnumerable<Vehicle>>> SearchVehiclesByName([FromQuery] string name)
        {
            var lowerName = name.ToLower();

            var vehicles = await _context.Vehicles
                .Where(v => v.Make.ToLower().Contains(lowerName) || v.Model.ToLower().Contains(lowerName))
                .ToListAsync();

            if (vehicles == null || vehicles.Count == 0)
            {
                return NotFound();
            }

            return vehicles;
        }


        private bool VehicleItemExists(int id)
        {
            return _context.Vehicles.Any(e => e.Id == id);
        }
    }
}